#include "base.cpp"
// #include "game_option.cpp"
#include "title_screen.cpp"

int main() {
  title_screen();
  return 0;
}
